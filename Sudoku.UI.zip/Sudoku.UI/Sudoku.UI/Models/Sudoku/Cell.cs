﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sudoku.UI.Models.Sudoku
{
    //This is the class used to get and set the values for each cell in the sudoku grid.
    public class Cell
    {
        public int? Value { get; set; }
        public List<int> PossibleValues { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
    }
}
